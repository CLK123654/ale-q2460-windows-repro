# 边缘网关Chart配置合并

preview和production已经按migration_plan.csv整理成独立values，并由同一套Chart生成候选清单。

版本负责人可从field_migration.csv回查旧字段去向，再用release_review.csv定位清单中的消费位置。现场安装、流量切换和运行观察由变更窗口值班处理。
